<?php

$checking_dirs = array(
                    'admin',
                    'cert',
                    'images',
                    'images/upload',
                    'images/upload/Image',
                    'images/upload/File',
                    'images/upload/Flash',
                    'images/upload/Media',
                    'data',
                    'data/afficheimg',
                    'data/brandlogo',
                    'data/cardimg',
                    'data/feedbackimg',
                    'data/sqldata',
                    'temp',
                    'temp/backup',
                    'temp/caches',
                    'temp/compiled',
                    'temp/compiled/admin',
                    'temp/query_caches/',
                    'temp/static_caches/',
                    'themes'
                    );

?>